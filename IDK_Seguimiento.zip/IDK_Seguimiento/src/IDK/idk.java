package IDK;

import java.util.Scanner;

public class idk {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        boolean continuar = true;
        
        while (continuar) {
         
            System.out.println("\nSeleccione el KPI que desea calcular:");
            System.out.println("1. ARPU (Ingresos Promedio por Usuario)");
            System.out.println("2. CAC (Costo de Adquisición de Clientes)");
            System.out.println("3. MRR (Ingresos Recurrentes Mensuales)");
            System.out.println("4. LTV (Valor del Tiempo de Vida del Cliente)");
            System.out.println("5. Churn Rate (Tasa de Cancelación de Clientes)");
            System.out.println("6. Runway (Tiempo de Sostenibilidad Financiera)");
            System.out.println("7. MoM (Mes sobre Mes)");
            System.out.println("8. Salir");
            System.out.print("Ingrese el número correspondiente al KPI que desea calcular: ");

            int seleccion = scanner.nextInt();
            switch (seleccion) {
                case 1:
                    calcularARPU(scanner);
                    break;
                case 2:
                    calcularCAC(scanner);
                    break;
                case 3:
                    calcularMRR(scanner);
                    break;
                case 4:
                    calcularLTV(scanner);
                    break;
                case 5:
                    calcularChurnRate(scanner);
                    break;
                case 6:
                    calcularRunway(scanner);
                    break;
                case 7:
                    calcularMoM(scanner);
                    break;
                case 8:
                    System.out.println("Gracias. ¡Hasta luego!");
                    continuar = false; 
                    break;
                default:
                    System.out.println("Opción no válida. Por favor, seleccione un número entre 1 y 8.");
            }
        }
         scanner.close();
    }

    // Método para calcular ARPU
    private static void calcularARPU(Scanner scanner) {
        System.out.println("Ingrese el total de ingresos mensuales:");
        double ingresosMensuales = scanner.nextDouble();
        System.out.println("Ingrese el número total de usuarios actuales:");
        int numeroUsuarios = scanner.nextInt();
        double arpu = ingresosMensuales / numeroUsuarios;
        System.out.println("ARPU (Ingresos Promedio por Usuario): $" + arpu);
    }

    // Método para calcular CAC
    private static void calcularCAC(Scanner scanner) {
        System.out.println("Ingrese el costo total de adquisición de clientes (CAC):");
        double costoAdquisicionClientes = scanner.nextDouble();
        System.out.println("Ingrese el número de clientes adquiridos este mes:");
        int clientesAdquiridos = scanner.nextInt();
        double cac = costoAdquisicionClientes / clientesAdquiridos;
        System.out.println("CAC (Costo de Adquisición de Clientes): $" + cac);
    }

 // Método para calcular MRR 
    private static void calcularMRR(Scanner scanner) {
        System.out.println("Ingrese el número total de suscripciones:");
        int numeroSuscripciones = scanner.nextInt();
        System.out.println("Ingrese el precio mensual de la suscripción:");
        double precioSuscripcion = scanner.nextDouble();
        double mrr = numeroSuscripciones * precioSuscripcion;
        System.out.println("MRR (Ingresos Recurrentes Mensuales): $" + mrr);
    }

 // Método para calcular LTV 
    private static void calcularLTV(Scanner scanner) {
        System.out.println("Ingrese el valor promedio de compra (ticket promedio):");
        double valorPromedioCompra = scanner.nextDouble();
        System.out.println("Ingrese la frecuencia de compra anual (cuántas veces compra al año un cliente promedio):");
        double frecuenciaCompraAnual = scanner.nextDouble();
        System.out.println("Ingrese la duración promedio de retención del cliente (en años):");
        double duracionRetencionCliente = scanner.nextDouble();
        double ltv = valorPromedioCompra * frecuenciaCompraAnual * duracionRetencionCliente;
        System.out.println("LTV (Valor del Tiempo de Vida del Cliente): $" + ltv);
    }

    // Método para calcular Churn Rate
    private static void calcularChurnRate(Scanner scanner) {
        System.out.println("Ingrese el número total de usuarios actuales:");
        int numeroUsuarios = scanner.nextInt();
        System.out.println("Ingrese el total de clientes perdidos este mes:");
        int clientesPerdidos = scanner.nextInt();
        double churnRate = (double) clientesPerdidos / numeroUsuarios * 100;
        System.out.println("Churn Rate (Tasa de Cancelación de Clientes): " + churnRate + "%");
    }

    // Método para calcular Runway
    private static void calcularRunway(Scanner scanner) {
        System.out.println("Ingrese el efectivo disponible para calcular el runway:");
        double efectivoDisponible = scanner.nextDouble();
        System.out.println("Ingrese el gasto mensual (quema de efectivo):");
        double gastoMensual = scanner.nextDouble();
        double runway = efectivoDisponible / gastoMensual;
        System.out.println("Runway (Tiempo de Sostenibilidad Financiera): " + runway + " meses");
    }

    // Método para calcular MoM (Month over Month)
    private static void calcularMoM(Scanner scanner) {
        System.out.println("Ingrese el valor inicial del mes:");
        double valorInicial = scanner.nextDouble();
        System.out.println("Ingrese el valor final del mes:");
        double valorFinal = scanner.nextDouble();
        double mom = ((valorFinal - valorInicial) / (valorInicial / 100));
        System.out.println("MoM (Mes sobre Mes): " + mom + "%");
    }
}
